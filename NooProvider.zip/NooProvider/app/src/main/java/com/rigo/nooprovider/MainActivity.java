package com.rigo.nooprovider;

import android.database.Cursor;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.Toast;

import com.rigo.nooprovider.db.NormalItemDBInfo;
import com.rigo.nooprovider.item.ItemArrayAdapter;
import com.rigo.nooprovider.item.NormalItem;
import com.rigo.nooprovider.util.AppLog;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private static String TAG = MainActivity.class.getSimpleName();

    static final Uri NOO_CONTENT_URI = Uri.parse("content://com.rigo.noo.provider");

    private ListView mListView;
    private ItemArrayAdapter mItemArrayAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mListView = (ListView)findViewById(R.id.lvItem);

    }

    public void getNOODB() {
        ArrayList<NormalItem> pListItem = new ArrayList<NormalItem>();
        NormalItem ptItem;
        Cursor pCursor = getContentResolver().query(NOO_CONTENT_URI,null, null, null, null);

        if(pCursor == null)
        {
            Toast.makeText(this,"pCursor is null", Toast.LENGTH_SHORT).show();
            return;
        }

        while ( pCursor.moveToNext() ) {
            ptItem = new NormalItem();
            ptItem.setStartTime( pCursor.getString(NormalItemDBInfo.ITEM_NORMAL_DB_FIELD_INDEX_STARTTIME));
            ptItem.setDistance( pCursor.getFloat(NormalItemDBInfo.ITEM_NORMAL_DB_FIELD_INDEX_DISTANCE) );
            ptItem.setData( pCursor.getLong(NormalItemDBInfo.ITEM_NORMAL_DB_FIELD_INDEX_DATA) );

            AppLog.i(TAG, "ptItem" + ptItem.getStartTime() );
            Toast.makeText(this,  "ptItem : " + ptItem.getStartTime(), Toast.LENGTH_SHORT).show();

            pListItem.add(ptItem);
        }
        pCursor.close();

        mItemArrayAdapter = new ItemArrayAdapter(this, R.layout.item_normal, pListItem);
        mListView.setAdapter(mItemArrayAdapter);
    }

    @Override
    protected void onResume() {
        super.onResume();
        getNOODB();
    }
}
